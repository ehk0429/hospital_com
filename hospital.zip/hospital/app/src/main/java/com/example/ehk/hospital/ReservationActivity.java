package com.example.ehk.hospital;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by ehk on 2018-01-12.
 */

public class ReservationActivity extends AppCompatActivity implements View.OnClickListener {

    private String date; //main 예약날짜 받을 변수
    private TextView dateText, textView_H, textView_M; //예약날짜 dataText / 시간 / 분
    private Button[] hbuttons = new Button[12]; //시간 버튼
    private Integer[] hbuttonIds = {R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btn10, R.id.btn11, R.id.btn12}; // 시간버튼 id
    private Button[] mbuttons = new Button[12];//분 버튼
    private Integer[] mbuttonIds = {R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4, R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9, R.id.button10, R.id.button11}; //분 버튼 id
    private ArrayList<String> hList = new ArrayList(); //시간 리스트
    private ArrayList<String> mList = new ArrayList();//분 리스트
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        Intent intent = new Intent(this.getIntent());
        date = intent.getStringExtra("날짜");
        dateText = findViewById(R.id.dateTextView);
        dateText.setText(date);

        textView_H = findViewById(R.id.textView_H);
        int index = hbuttons.length;
        for (int i = 0; i < index; i++) {
            hbuttons[i] = findViewById(hbuttonIds[i]);
            hbuttons[i].setOnClickListener(this);
            hbuttons[i].setTag(i);
            hList.add(i + 1 + "시 ");
        }
        textView_M = findViewById(R.id.textView_M);
        int index2 = mbuttons.length;
        for (int i = 0; i < index2; i++) {
            mbuttons[i] = findViewById(mbuttonIds[i]);
            mbuttons[i].setOnClickListener(this);
            mbuttons[i].setTag(i);
            mList.add(i * 5 + "분");
        }
    }
    public void onClick(View view) {
        Button newButton = (Button) view;
        for (Button button : hbuttons) { // 시간버튼
            if (button == newButton) {
                int position = (Integer) view.getTag();
                textView_H.setText(hList.get(position));
                Log.d("1", "시간");
            }
        }
        for (Button button : mbuttons) { // 분버튼
            if (button == newButton) {
                int position = (Integer) view.getTag();
                textView_M.setText(mList.get(position));
                Log.d("2", "분");
            }
        }
    }
    public void reserve(View v) { // (reserveBtn )예약 완료버튼 클릭 시 시간과 분 미선택 시 예약 완료 못하게
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        int count = 5;
        if (TextUtils.isEmpty(textView_H.getText())||TextUtils.isEmpty(textView_M.getText())) {
            Toast toast = Toast.makeText(this,"예약 시간을 선택하세요!",Toast.LENGTH_SHORT);
            View toastView = toast.getView();
            toastView.setBackgroundResource(R.color.toast);//색변경
            toast.show();
            Log.d("미선택","미선택");
        } else {//팝업
            builder.setTitle("예약 현황")
                    .setMessage(count+"명 예약 가능, 예약하시겠습니까?")
                    .setCancelable(false)
                    .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(), "예약이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(intent);
                        }
                    });
            builder.show();
        }
    }
    public void topLeft(View v) {//topLeft 버튼 클릭시
        if(v.isPressed()){
            mbuttons[10].setPressed(true);
        }else{
            mbuttons[10].setPressed(false);
        }
        textView_M.setText("50분");
        Log.d("50분", "topLeft");
    }
    public void bottomLeft(View v) {// bottomLeft 버튼 클릭시
        if(v.isPressed()){
            mbuttons[7].setPressed(true);
        }else{
            mbuttons[7].setPressed(false);
        }
        textView_M.setText("35분");
        Log.d("35분", "bottomLeft");
    }
    public void bottomRight(View v) {//bottomRight 버튼 클릭시
        if(v.isPressed()){
            mbuttons[4].setPressed(true);
        }else{
            mbuttons[4].setPressed(false);
        }
        textView_M.setText("20분");
        Log.d("20분", "bottomRight");
    }
    public void topRight(View v) {//topRight 버튼 클릭시
        if(v.isPressed()){
            mbuttons[1].setPressed(true);
        }else {
            mbuttons[1].setPressed(false);
        }
        textView_M.setText(" 5분");
        Log.d("5분", "topRight");
    }
}